class AppConfig {
  static const email = 'blood.donations.lb@gmail.com';
  static const bloodDonationInfoLink =
      'https://www.moph.gov.lb/en/Pages/4/3262/blood-transfusion-';
}
