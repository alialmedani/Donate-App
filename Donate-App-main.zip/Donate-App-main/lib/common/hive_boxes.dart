class ConfigBox {
  static const key = 'configBox';
  static const isFirstLaunch = 'isFirstLaunch';
  static const bloodType = 'bloodType';
  static const isAdmin = 'isAdmin';
}
