class Fonts {
  static const logo = 'Courgette';
  static const text = 'SF';
}
